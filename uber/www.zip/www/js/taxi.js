(function () {
	function Taxi () {};
}) ();