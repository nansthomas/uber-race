(function () {
	function Game () {};
	Game.prototype = {
		init: function (app) {
			app.startGame();
			
		},
		end function () {
			
		}
	}
}) ()