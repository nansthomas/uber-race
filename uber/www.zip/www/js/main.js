//(function () {
	var longueur = 40,
		largeur = 4,
		grille = [],
		bgColor = "0a0e34", // couleur du fond
		lineColor = "ffffff",
		canvas = document.getElementById("canvas"),
		context = canvas.getContext("2d"),
		pause = document.getElementById("pause"),
		play = document.getElementById("play"),
		divScore = document.getElementById("score"),
		divCanvas = document.getElementById("divCanvas"),
		speed = 50, //vitesse du jeu en ms
		speedLimit = 20,
		speedObstSpawn = 900,
		speedObstSpawnLimit = 300,
		speedIncrInt = 15000,
		nbObstMaxScreen = 10,
		nbObstMaxLine = 2,
		obstaclesArray = [],
		compteurObst = 0,
		stateGame = 1,
		score = 0,
		coeffScore = speed,
		uber = new Uber(),
		uberInt = "",
		obstSpawnInt = "",
		colors = ["Blue", "Green", "Orange", "Pink", "Purple", "Red"];
		divCanvas.style.width = window.innerWidth + 'px';
		divCanvas.style.height = window.innerHeight + 'px';


	function init () {
		for (var i = 0; i < largeur; i++) {
			grille[i] = [];
			for (var j = 0; j < longueur; j++) {
				grille[i][j] = 0;
			}
		}
		for (var i = 0; i < nbObstMaxScreen; i++) {
			obstaclesArray[i] = new Obstacle();
		}
	}

	function background () {
		context.fillStyle = "#" + bgColor;
		context.globalAlpha = 1;
		context.fillRect(0,0,canvas.width,canvas.height); //taille colonnes : 180 +2+ 192 +2+ 192 +2+ 180
		context.fillStyle = "#" + lineColor;
		for (var i = 0; i < largeur; i++) {
			context.globalAlpha = 0.15;
			context.fillRect(192 + (i*192), 200, 2, 1300);
		}
		context.globalAlpha = 1;
	}

	function endGame () {
		stateGame = 0;
		clearInterval(increaseSpeedInt);
		clearInterval(uberInt);
		clearInterval(obstSpawnInt);
	}

	function pauseGame () {
		if (stateGame == 1) {
			stateGame = 2;
			clearInterval(increaseSpeedInt);
			clearInterval(uberInt);
			clearInterval(obstSpawnInt);
			pause.style.display = "none";
			play.style.display = "block";
		}
	}

	function newObst () {
		var positionArray = [];
		for (var i = 0; i < nbObstMaxLine; i++) {
			var position = Math.floor(Math.random()*largeur);
			if (positionArray.lastIndexOf(position) == -1) positionArray.push(position);
		}
		for (var i = 0; i < positionArray.length; i++) {
			obstaclesArray[(i + compteurObst) % nbObstMaxScreen].init(positionArray[i], grille, randomColors(), context);
		}
		compteurObst += positionArray.length;
	}

	function obstMove () {
		for (var i = 0; i < compteurObst && i < nbObstMaxScreen; i++) {
			obstaclesArray[i].move(grille, context);
		}
	}

	function randomColors () {
		return colors[Math.floor(Math.random()*colors.length)];
	}

	function verifEndGame () {
		if(!uber.get("etat")) endGame();
		for (var i = 0; i < compteurObst && i < nbObstMaxScreen; i++) {
			if(!obstaclesArray[i].get("etat")) endGame();
		}
	}

	function increaseSpeedGame () {
		var speedIncr = 5;
		clearInterval(uberInt);
		if (speed - speedIncr >= speedLimit) speed -= speedIncr;
		else speed = speedLimit;
		uberInt = setInterval(function () {
			context.clearRect(0, 0, canvas.width, canvas.height);
			context.beginPath();
			background();
			uber.move(grille, context);
			obstMove();
			verifEndGame();
			score += 5 + (5*(coeffScore-speed));
			document.getElementById("score").innerHTML = score;
		}, speed);
	}

	function increaseSpeedObstSpawn () {
		var speedIncr = 100;
		clearInterval(obstSpawnInt);
		if (speedObstSpawn - speedIncr >= speedObstSpawnLimit) speedObstSpawn -= speedIncr;
		else speedObstSpawn = speedObstSpawnLimit;
		obstSpawnInt = setInterval(function () {
			newObst();
		}, speedObstSpawn);
	}

	function startGame () {
//		obstaclesArray[0].init(0, grille, 'Blue', context);
		if (stateGame != 0) {
			increaseSpeedInt = setInterval(function () {
				increaseSpeedGame();
				increaseSpeedObstSpawn();
			}, speedIncrInt);
			obstSpawnInt = setInterval(function () {
				newObst();
			}, speedObstSpawn);
			uber.init(grille, context);
			uberInt = setInterval(function () {
				context.clearRect(0, 0, canvas.width, canvas.height);
				context.beginPath();
				background();
				uber.move(grille, context);
				obstMove();
				verifEndGame();
				score += 5 + (5*(coeffScore-speed));
				document.getElementById("score").innerHTML = score;
			}, speed);
			stateGame = 1;
			play.style.display = "none";
			pause.style.display = "block";
		}
	}

	init();
	background();
	startGame();
//}) ();
